﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Kamil Kaygisiz
**				ÖĞRENCİ NUMARASI.......:B211210381
**                         DERSİN ALINDIĞI GRUP...:1\B
****************************************************************************/

using System;
using System.Text.RegularExpressions;

namespace staticClassHw
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isPossible = true;// hesaplamalarin devam etmesi icin
            int totalPoint ;//total pointi tutmak ve goruntulerken yazdirilmasi icin tanimlandi
            string isStrong = "";//90 dan buyukse buraya guclu gelir 
            do
            {
                do
                {//String.Any(Char.isSpace) kullanilabilir system.linq eklenilerek alttakiyle ayni islevi gorur
                    Regex regexx = new Regex(@"\s");//stringin icinde whitespaces var mı konrtrol icin kullanildi password.Contains(" ") olmazdi tab lf gibi whitespacesleri saymiyor
                    string password = "";
                    int howMany = 0;// her seferinde resetlemek gerekli
                    totalPoint = 0;
                    Passwordd.Resett();//static clasin elemanlari da static oldugu icin hepsinin tekar sifirlanmasi gerekmektedir
                    Console.Write("Please enter your password:");
                    password = Console.ReadLine();
                    howMany = password.Length;//passwordun uzunlugunu al 9 a esit kucuk buyuk mu kontrolu icin


                    Passwordd.Setter(password);//kontroller icin passwordu class methoduna arguman olarak gonder,instance of classa gerek yok cunku class static
                    if (regexx.IsMatch(password))//verilen pattern \s yani whitespaces -eslesiyor mu diye kontrol edildi
                    {
                        Console.WriteLine("Parola icerisinde bosluk olamaz tekrar deneyiniz");
                        continue;
                    }

                    if (Passwordd.capitalNum > 1)//buyuk harf sayisi 1'den buyukse 20 puan esit veya azsa 20 eklenecek
                    {
                        totalPoint += 20;
                    }
                    else { totalPoint += Passwordd.capitalNum * 10; }

                    if (Passwordd.smallNum > 1)
                    {
                        totalPoint += 20;
                    }
                    else { totalPoint += Passwordd.smallNum * 10; }

                    if (Passwordd.digitNum > 1)
                    {
                        totalPoint += 20;
                    }
                    else { totalPoint += Passwordd.digitNum * 10; }

                    totalPoint += Passwordd.symbolNum * 10;//symbol icin oyle bir sinir olmadigi icin symbolsayisi*10 seklinde puan eklenmeye devam ediliyor
                    if (howMany == 9 || howMany > 9)
                    {
                        if (Passwordd.IsAllNotZero(password))//karakter 9a esit veya buyukse her seyden karakter sayi sembol .. en az birer adet olmasi gerekir
                        {
                            if (howMany > 9)
                            {
                                if (totalPoint >= 70)
                                {
                                    isPossible = false;// donguden cikis icin boolun degeri false atandi
                                }
                            }

                            if (howMany == 9)
                            {
                                totalPoint += 10;//9 a aesitse +10 puan eklenecek
                                if (totalPoint >= 70)//70 degilse parola kabul edilmez
                                {// total puan 70 e ulastiysa ic donguden cikacak degilse ustte yapilan ekleme de dongunun bainda tekrar sifirlanacak
                                    isPossible = false;
                                }
                            }

                        }
                        else
                        {
                            Console.WriteLine("Büyük harf, küçük harf, rakam ve sembol sayısının hiçbiri sıfır olamaz tekrar deneyiniz");
                            Passwordd.Display(); Console.WriteLine($"Puan={totalPoint}");
                        }

                    }
                    else
                    {//sartlarin saglanmasi icin en az 9 karakter veya 70 point olması gerekli 9 veyaz fazla degilse 70 olması imkansiz oldugu icin yeni bir ife gerek duyulmadi
                        Console.WriteLine("Girdiginiz password sartlari saglamıyor en az 9 karakter girisi saglanmali  lutfen tekrar deneyiniz");
                        Passwordd.Display(); Console.WriteLine($"Puan={totalPoint}");//goruntule 
                    }

                } while (isPossible);
                Console.WriteLine("Parola gecerli!");
                Passwordd.Display(); Console.WriteLine($"Puan={totalPoint}");
                if (totalPoint >= 90 )
                {
                    isStrong = "Güclü parola!";
                    Console.WriteLine(isStrong);
                }
                Console.WriteLine("Cikis yapmak icin ESC tusuna tiklayin,devam etmek icin herhangi bir tusa tiklayin");
            } while ((Console.ReadKey(true).Key)!=ConsoleKey.Escape);//ReadKey in icine true parametresini vermemin sebebi tekrar parola girisi olacagi icin ekrana print edilmeyerek
            //kullanicinin muhteml kafa karisikligini onlemek

            
        
        }
       
        
    }
}
