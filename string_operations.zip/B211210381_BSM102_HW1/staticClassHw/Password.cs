﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Kamil Kaygisiz
**				ÖĞRENCİ NUMARASI.......:B211210381
**                         DERSİN ALINDIĞI GRUP...:1\B
****************************************************************************/



using System;

namespace staticClassHw
{

    static class Passwordd
    {//static data member kullanildi .static class sadece static method ve uyelere sahip olabilir
        public static int smallNum = 0;
        public static int capitalNum = 0;
        public static int symbolNum = 0;
        public static int digitNum = 0;
        public static void Setter(string passwordd)
        {
          
         foreach(char c in passwordd){
                if (Char.IsLetter(c))//harf mi
                {
                    if (Char.IsLower(c))//harfse kucuk harf mi
                    {
                       smallNum++;
                    }
                    else if (Char.IsUpper(c))// buyuk harf mi oyleyse sayiyi artir
                    {
                        capitalNum++;
                    }
                }
                else if (Char.IsDigit(c))
                {
                    digitNum++;
                }
                else //karakter veya sayi degilse semboldür denilebilir(Char.IsSymbol(c) ? \ gibi sembolleri karakter saymiyor derste sayilmasi istendi
                {
                    symbolNum++;
                }                
            }
        }

        static public void Resett()
        {
         smallNum = 0;
         capitalNum = 0;
         symbolNum = 0;
         digitNum = 0;
         }
        static public bool IsAllNotZero(string password)
        {
            //karakter sayisinin 9 dan fazla olmasi durumunda hepsinin total sayisinin sifirdan farkli olmasi gerekli
            bool isTrue;
            if (smallNum != 0 && capitalNum != 0 && symbolNum != 0 && digitNum != 0)
                isTrue = true;
            else 
                 isTrue=false;

            return isTrue;
        }
        static public void Display()
        {// passwordun ozelliklerini goruntuler.
            Console.WriteLine($"Kucuk harf sayisi={smallNum}\nBuyuk harf sayisi={capitalNum}\nSembol sayisi={symbolNum}\nNumara sayisi={digitNum}");
        }
   }
}
